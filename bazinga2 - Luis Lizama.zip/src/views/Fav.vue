<template>
    <div class="banner">
       <div>
<!-- Banner -->
  <b-jumbotron class="banner" header="Favoritos" lead="¡Guarda esas series que andas buscando!">
  </b-jumbotron>

    <b-container class="my-5" 
    v-if="FavoritoTrue">
      <b-row align-h="center">
        <b-col cols="8">
          <b-input-group align-h="center">
            <b-form-input 
            size="sm" 
            v-model="busquedafav" 
            prepend="Buscar" 
            class="mr-sm-2" 
            placeholder="Escribe acá para buscar en tu Recetario (sólo en inglés)"></b-form-input>
          </b-input-group>
        </b-col>
      </b-row>
    </b-container>
    <b-container class="bv-example-row">
      <b-row  align-h="center"> 
        <b-card-group deck v-for="(item,index) in FavoritoCorazon" :key="index">
          <card 
          :imagen="item.imagen" 
          :nombre="item.nombre" 
          :uri="item.uri" 
          :ingredientes="item.ingredientes" 
          :url="item.url" 
          :fav="false" 
          ></card>                   
        </b-card-group>
      </b-row>
    </b-container>
</div>
    </div>
</template>
<script>
import store from '../store/index';
import CardSerie from '../components/CardSerie'
export default {
  name:'Fav',
    component:{
 CardSerie
    },
    data(){
      return{
        InputFavorito:'',
      }
    },
    computed:{
      FavoritoCorazon(){
        return store.state.Fav.filter((e)=>{return e.Nombre.toLowerCase().includes(this.InputFavorito)
      })},
      FavoritoTrue(){
        let corazon = ''
        if(store.state.FavName.length==0){
          corazon = false
        }else{corazon = true}
        return corazon
      }
    }
    }
</script>
<style lang="scss" scoped>
    .banner{
        background-image: url(".././assets/img/BG-3.jpg");
          background-position: center center;
          background-size: cover;
          color: black;
        } h1{
          font-family: 'Bangers', cursive  
        }p{
           font-family: 'Roboto', sans-serif;
           font-weight: 500;
           font-size:2rem
        }
   
    
        
</style>