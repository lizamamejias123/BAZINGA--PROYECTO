<template>
<div> 
<!-- Banner -->
<b-jumbotron class="banner">
<!-- Bazinga Imagen -->
<img src="@/assets/img/bazinga.png" alt="">
<!-- Texto Principal -->
   <H1>Bazinga! Tu nuevo buscador de series</H1>
   <p>Sitio Web destinado a todo tipo de fans de series de ciencia ficción</p>
  </b-jumbotron>
  <!-- Buscador -->
<b-container class="bv-example-row" fluid>
          <b-container class="my-5">
            <b-row align-h="center">
              <b-col cols="10">
                <b-input-group align-h="center">
                  <b-form-input 
                  size="xl" 
                  v-model="Busqueda" 
                  class="mr-sm-2" 
                  placeholder="Encuentra tu serie... Ej: Arrow">
                  </b-form-input>
                  <b-button 
                  size="xl" 
                  class="ml-2" 
                  variant="primary" 
                  style="color:white"
                  @click.prevent="Buscar()" >Buscar</b-button>
                </b-input-group>
              </b-col>
            </b-row>
          </b-container>
    </b-container>
    <b-container class="bv-example-row">
          <b-row align-h="center">
            <b-card-group deck v-for="(item,index) in SeriesBuscadas" :key="index">
              <CardSerie 
              :ImagenBg="item.Poster"
               :Titulo="item.Title" 
               :Year="item.Year" 
              :corazon="true"></CardSerie>
            </b-card-group>
          </b-row>
        </b-container>     
    
</div>
</template>
<script>


import store from '../store/index'
import CardSerie from '../components/CardSerie.vue'
import axios from 'axios'

export default {
    components:{
        CardSerie,
    },
    data(){
      return{
        Busqueda:''}
    },
    methods:{
    Buscar(){
      if(this.Busqueda!=''){
        store.dispatch('Buscador',this.Busqueda)
        this.Busqueda=''
      }else{
      }  
    }},
    
    computed:{
    SeriesBuscadas(){
        return store.getters.ListaSerie
    }}
 }
</script>
<style lang="scss" scoped>
    .banner{
        background-image: url(".././assets/img/BG-0.jpg");
          background-position: center center;
          background-size: cover;
        }
        h1{
          font-family: 'Bangers', cursive;
          color: #E72831;
        }p{
           font-family: 'Roboto', sans-serif;
           font-weight: 500;
           font-size: 2rem;
           color: black;
        }
   
    
        
</style>