<template>
    <div>
<!-- Inicio Navbar -->
  <b-navbar toggleable="lg" class="transparent">
<!-- Logo -->
    <b-navbar-brand href="#"><img class="navbar_img mr-auto" src="@/assets/img/bazinga.png" alt="logo"></b-navbar-brand>
    <b-navbar-toggle target="nav-collapse"></b-navbar-toggle>
    <b-collapse id="nav-collapse" is-nav>
<!-- Items derecha -->
      <b-navbar-nav class="ml-auto">
<!-- Home -->
        <router-link to="/" class="nav-link">Home</router-link>
<!-- Registrate / Favoritos -->
        <b-navbar-nav v-if=this.$store.state.ver>
        <router-link to="/RegistroUser" class="nav-link" >Registrate</router-link> </b-navbar-nav>

        <b-navbar-nav v-if=!this.$store.state.ver>
        <router-link to="/Fav" class="nav-link">Favorito</router-link> </b-navbar-nav>

<!-- Login / Perfil-->
<b-navbar-nav v-if=this.$store.state.ver>
<router-link to="/Login" class="nav-link">Login</router-link> </b-navbar-nav>
       
        <b-nav-item-dropdown right  v-if=!this.$store.state.ver>
          <template v-slot:button-content>
            <em>Hola</em>
          </template>
           <router-link to="/Perfil" class="nav-link">Perfil</router-link> 
          <b-dropdown-item @click='LogOut'>Sign Out</b-dropdown-item>
        </b-nav-item-dropdown>
      </b-navbar-nav>
    </b-collapse>
  </b-navbar>
</div>
</template>

<script>
export default {
    name:'NavbarPrincipal',
    methods:{
      LogOut(){
        this.$store.commit('LogOut')
      }
    }
}
</script>
<style lang="scss">
    .navbar_img{
        max-height: 4rem!important 
    }
    .transparent{
        background-color: #109AE8!important;
    }

</style>