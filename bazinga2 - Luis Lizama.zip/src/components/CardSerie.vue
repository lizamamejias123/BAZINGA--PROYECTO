<template>
    <div>
        <b-card
            :img-src=" ImagenBg" no-body 
            img-alt="Image" img-top tag="article" 
            style="max-width: 20rem;" 
            class="mb-2 mx-4" 
            footer-bg-variant="white">
            <template v-slot:header>
                <div>                
                    {{Titulo}}                
                </div>
            </template>     
            <!-- <template v-slot:footer>           
                <b-button href="#" variant="danger" v-b-modal="uri" class="mx-2">Ingredientes</b-button> -->
                <!--BOTON VISTA HOME-->                   
                <!-- <b-button v-if="corazon" href="#" :variant="botonActivo?'outline-danger':'danger'" @click.once="Like(uri)" :disabled="botonActivo" class="mx-2">{{botonActivo? 
                'Guardada':'Favoritos'}}</b-button>                 -->

            <!--BOTON VISTA FAVORITOS -->
                <!-- <b-button v-else  variant="danger" @click="Dislike(uri)" class="mx-2">Quitar Favorito</b-button>
            </template>           -->
        </b-card>  
    </div>
</template>

<script>
    import store from '../store/index'
    export default {
        name:'CardSerie',
        props:{
            ImagenBg:String,
            Titulo: String,
            Year:String,
            corazon:Boolean,
        }, data(){
            return{
            }},
        methods: {
            Like(e){
                if (store.state.Idu!=''){
                    return store.dispatch('Favorito',e)
                }
            },
            Dislike(algo){
            store.state.listaFav.map((e,i)=>{
            if(e.nombre==a){
            store.state.listaFav.splice(i,1)
             return store.dispatch('DeteleFavorito',a)}})
        },},
        
        computed: {
            botonActivo(){
                if(store.state.Idu!=''){
                    return store.state.FavName.includes(this.Titulo)
                }else{
                    return false
                }                
            }
        },
    }
</script>