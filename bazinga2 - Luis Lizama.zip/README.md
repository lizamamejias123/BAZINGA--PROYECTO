# Bazinga

<img style="margin:auto" width="500px" alt="bazinga" src="/public/img/icons/bazinga.png">

Bazinga es un Sitio Web en el cual puedes encontrar información de Series de ciencia ficción derivadas de Comic. Podras encontrar de todas las series actuales con cantidad de episodios, filtrar por nombre de la serie.

## Guia de Estilo


## Diseño



## Instalacion del proyecto
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Run your unit tests
```
npm run test:unit
```

### Run your end-to-end tests
```
npm run test:e2e
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
