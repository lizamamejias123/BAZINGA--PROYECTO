import Vue from "vue";
import Vuex from "vuex";

Vue.use(Vuex);

export default new Vuex.Store({
    state: {
        Correo: '',
        Clave: '',
        Nombre: '',
        ver: true,
        datos: null,
        usuarioID: '',
        Busqueda: '',
        cambios: true,
        listaFav: [],
        NombresFav: []
    },
    mutations: {
        // 1. Obtener action de mutation RecuperarLaContraseña
        RECUPERAR_LA_CONTRASEÑA(state, valor) {
            firebase.auth().sendPasswordResetEmail(valor).then(function() {
                this.$buefy.dialog.alert({
                    title: 'Cambio de contraseña',
                    message: 'Se ha mandado una nueva contraseña a tu correo',
                    type: 'is-success',
                    hasIcon: true,
                    icon: 'envelope',
                    iconPack: 'fa',
                    ariaRole: 'alertdialog',
                    ariaModal: true
                })
            }).catch(function(error) {
                if (error.code == 'auth/user-not-found') {
                    this.$buefy.dialog.alert({
                        title: 'El correo no tiene usuario',
                        message: 'El correo no tiene un usuario registrado, deberías registrarte',
                        type: 'is-danger',
                        hasIcon: true,
                        icon: 'times-circle',
                        iconPack: 'fa',
                        ariaRole: 'alertdialog',
                        ariaModal: true
                    })
                }
            })
        },
        LOGIN(state, valor) {
            let Email = valor[0]
            let Password = valor[1]
                // Firebase Entrar con email y contraseña
            firebase.auth().signInWithEmailAndPassword(Email, Password).then((respuesta) => {
                state.usuarioID = respuesta.user.uid
                state.correo = Email
                state.clave = Password
                state.Busqueda = ''
                db.collection(state.usuarioID).get().then((querySnapshot) => {
                    querySnapshot.forEach((doc) => {
                        state.Nombre = doc.data().Nombre
                    })
                }).then(() => {
                    state.listaFav = []
                    state.NombresFav = []
                    db.collection(state.usuarioID).doc('SerieFavorita').collection('SerieFavorita').get().
                    then((querySnapshot) => {
                        querySnapshot.forEach((doc) => {
                            let favorite = {
                                Nombre: doc.data().Nombre,
                                imagen: doc.data().imagen,
                                ingredientes: doc.data().ingredientes,
                                url: doc.data().url
                            }
                            state.listaFav.push(favorite)
                            state.NombresFav.push(favorite.Nombre)
                        })
                    });
                }).then(() => {
                    API()
                    setTimeout((function() { router.push('/') }), 1000)
                })
                state.ver = false
            }).catch(error => {
                if (error.code == 'auth/user-not-found') {
                    // Usuario no encontrado
                } else if (error.code == 'auth/invalid-Email') {
                    //  correo invalido
                } else if (error.code == 'auth/wrong-Password') {
                    //  clave invalida
                }
            })
        },

    },
    actions: {
        //  1. Action de recuperar contraseña 
        RecuperarLaContraseña(context, info) {
            context.commit('RECUPERAR_LA_CONTRASEÑA', info)
        }
    },
    modules: {},
    getters: {
        ListaSerie(state) {
            return state.datos
        }
    }
});