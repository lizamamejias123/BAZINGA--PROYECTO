<template>
    <div>
<!-- Inicio Navbar -->
  <b-navbar toggleable="lg" class="transparent">
<!-- Logo -->
    <b-navbar-brand href="#"><img class="navbar_img mr-auto" src="@/assets/img/bazinga.png" alt="logo"></b-navbar-brand>
    <b-navbar-toggle target="nav-collapse"></b-navbar-toggle>
    <b-collapse id="nav-collapse" is-nav>
<!-- Items derecha -->
      <b-navbar-nav class="ml-auto">
<!-- Home -->
        <router-link to="/" class="routerLink nav-link">Home</router-link>
<!-- Registrate / Favoritos -->
        <router-link to="/RegistroUser" class="routerLink nav-link">Regístrate</router-link>
        <router-link to="/Fav" class="routerLink nav-link">Favorito</router-link>
<!-- Login / Perfil-->
<router-link to="/Login" class="routerLink nav-link">Login</router-link>
        <b-nav-item-dropdown right>
          <template v-slot:button-content>
            <em>Perfil</em>
          </template>
<!-- Perfil -->
<router-link to="/Perfil" class="routerLink nav-link">Perfil</router-link>
         
<!-- Desconectarse  o Log Out -->
          <b-dropdown-item href="#">Sign Out</b-dropdown-item>
        </b-nav-item-dropdown>
      </b-navbar-nav>
    </b-collapse>
  </b-navbar>
</div>
</template>

<script>
export default {
    name:'NavbarPrincipal'
}
</script>
<style lang="scss">
    .navbar_img{
        max-height: 4rem!important 
    }
    .transparent{
        background-color: #109AE8!important;
    }

</style>