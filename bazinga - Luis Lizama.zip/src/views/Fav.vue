<template>
    <div class="banner">
       <div>
<!-- Banner -->
  <b-jumbotron class="banner" header="Favoritos" lead="¡Guarda esas series que andas buscando!">
     
  </b-jumbotron>

</div>
    </div>
</template>
<script>

export default {
    component:{

    }
}
</script>
<style lang="scss" scoped>
    .banner{
        background-image: url(".././assets/img/BG-3.jpg");
          background-position: center center;
          background-size: cover;
          color: black;
        } h1{
          font-family: 'Bangers', cursive  
        }p{
           font-family: 'Roboto', sans-serif;
           font-weight: 500;
           font-size:2rem
        }
   
    
        
</style>