<template>
    <div class="banner">
       <div>
<!-- Banner -->
  <b-jumbotron class="banner" header="Error 404">
      <div class="home_text">
   <h3>¿Andas perdido?, Presiona el logo de Bazinga! y andaté al home</h3>
   </div>
  </b-jumbotron>

</div>
    </div>
</template>
<script>

export default {
    component:{

    }
}
</script>
<style lang="scss" scoped>
    .banner{
        background-image: url(".././assets/img/BG-2.jpg");
          background-position: center center;
          background-size: cover;
          color: black;
        }
    .home_text{
            padding: 50px;
        }
    
        
</style>